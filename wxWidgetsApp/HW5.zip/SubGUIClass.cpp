#include "SubGUIClass.h"



SubGUIClass::SubGUIClass(wxWindow* parent)
	:
	GUIClass(parent)
{
	//initialize character array
	for (int i = 0; i < 9; i++)
	{
		c[i] = 'R';
	}
}

void SubGUIClass::onExitSelected( wxCommandEvent& event )
{
	//event that controls exit button
	int answer = wxMessageBox("Quit program?", "Confirm", wxYES_NO, this);
	if (answer == wxYES)
	{
		Close();
	}
}

void SubGUIClass::setSymbol( wxCommandEvent& event )
{
	wxString s, j;
	pButton = wxDynamicCast(event.GetEventObject(), wxButton);

	s = pButton->GetName();
	double *k = new double;

	pButton->GetId();

	j = s(7, 1);

	j.ToDouble(k);
	int i = pButton->GetId();

	//sets label and character array
	if (isXturn)
	{
		pButton->SetLabel("X");
		c[i] = 'X';
	}
	if (isOturn)
	{
		pButton->SetLabel("O");
		c[i] = 'O';
	}

	//switches turn
	if (isXturn)
	{
		isOturn = true;
		isXturn = false;
	}
	else
	{
		isOturn = false;
		isXturn = true;
	}
	
	//checks if there is a winner
	if ((c[0] == 'X' && c[1] == 'X' && c[2] == 'X') ||
		(c[3] == 'X' && c[4] == 'X' && c[5] == 'X') ||
		(c[6] == 'X' && c[7] == 'X' && c[8] == 'X') ||
		(c[0] == 'X' && c[3] == 'X' && c[6] == 'X') ||
		(c[1] == 'X' && c[4] == 'X' && c[7] == 'X') ||
		(c[2] == 'X' && c[5] == 'X' && c[8] == 'X') ||
		(c[0] == 'X' && c[4] == 'X' && c[8] == 'X') ||
		(c[6] == 'X' && c[4] == 'X' && c[2] == 'X'))
	{
		int answer = wxMessageBox("X wins. Play Again?", "Confirm", wxYES_NO, this);
		if (answer == wxYES)
		{
			m_button1->SetLabel("");
			m_button2->SetLabel("");
			m_button3->SetLabel("");
			m_button4->SetLabel("");
			m_button5->SetLabel("");
			m_button6->SetLabel("");
			m_button7->SetLabel("");
			m_button8->SetLabel("");
			m_button9->SetLabel("");

			for (int i = 0; i < 9; i++)
			{
				c[i] = 'R';
			}
		}
		if (answer == wxNO)
		{
			int answer = wxMessageBox("Quit program?", "Confirm", wxYES_NO, this);
			if (answer == wxYES)
			{
				Close();
			}
			if (answer == wxNO)
			{
				m_button1->SetLabel("");
				m_button2->SetLabel("");
				m_button3->SetLabel("");
				m_button4->SetLabel("");
				m_button5->SetLabel("");
				m_button6->SetLabel("");
				m_button7->SetLabel("");
				m_button8->SetLabel("");
				m_button9->SetLabel("");

				for (int i = 0; i < 9; i++)
				{
					c[i] = 'R';
				}
			}
		}
	}
	if ((c[0] == 'O' && c[1] == 'O' && c[2] == 'O') ||
		(c[3] == 'O' && c[4] == 'O' && c[5] == 'O') ||
		(c[6] == 'O' && c[7] == 'O' && c[8] == 'O') ||
		(c[0] == 'O' && c[3] == 'O' && c[6] == 'O') ||
		(c[1] == 'O' && c[4] == 'O' && c[7] == 'O') ||
		(c[2] == 'O' && c[5] == 'O' && c[8] == 'O') ||
		(c[0] == 'O' && c[4] == 'O' && c[8] == 'O') ||
		(c[6] == 'O' && c[4] == 'O' && c[2] == 'O'))
	{
		int answer = wxMessageBox("O wins. Play Again?", "Confirm", wxYES_NO, this);
		if (answer == wxYES)
		{
			m_button1->SetLabel("");
			m_button2->SetLabel("");
			m_button3->SetLabel("");
			m_button4->SetLabel("");
			m_button5->SetLabel("");
			m_button6->SetLabel("");
			m_button7->SetLabel("");
			m_button8->SetLabel("");
			m_button9->SetLabel("");

			for (int i = 0; i < 9; i++)
			{
				c[i] = 'R';
			}
		}
		if (answer == wxNO)
		{
			int answer = wxMessageBox("Quit program?", "Confirm", wxYES_NO, this);
			if (answer == wxYES)
			{
				Close();
			}
			if (answer == wxNO)
			{
				m_button1->SetLabel("");
				m_button2->SetLabel("");
				m_button3->SetLabel("");
				m_button4->SetLabel("");
				m_button5->SetLabel("");
				m_button6->SetLabel("");
				m_button7->SetLabel("");
				m_button8->SetLabel("");
				m_button9->SetLabel("");

				for (int i = 0; i < 9; i++)
				{
					c[i] = 'R';
				}
			}
		}
	}
	if (c[0] != 'R' &&
		c[1] != 'R' &&
		c[2] != 'R' &&
		c[3] != 'R' &&
		c[4] != 'R' &&
		c[5] != 'R' &&
		c[6] != 'R' &&
		c[7] != 'R' &&
		c[8] != 'R')
	{
		int answer = wxMessageBox("Tie Game. Play Again?", "Confirm", wxYES_NO, this);
		if (answer == wxYES)
		{
			m_button1->SetLabel("");
			m_button2->SetLabel("");
			m_button3->SetLabel("");
			m_button4->SetLabel("");
			m_button5->SetLabel("");
			m_button6->SetLabel("");
			m_button7->SetLabel("");
			m_button8->SetLabel("");
			m_button9->SetLabel("");

			for (int i = 0; i < 9; i++)
			{
				c[i] = 'R';
			}
		}
		if (answer == wxNO)
		{
			int answer = wxMessageBox("Quit program?", "Confirm", wxYES_NO, this);
			if (answer == wxYES)
			{
				Close();
			}
			if (answer == wxNO)
			{
				m_button1->SetLabel("");
				m_button2->SetLabel("");
				m_button3->SetLabel("");
				m_button4->SetLabel("");
				m_button5->SetLabel("");
				m_button6->SetLabel("");
				m_button7->SetLabel("");
				m_button8->SetLabel("");
				m_button9->SetLabel("");

				for (int i = 0; i < 9; i++)
				{
					c[i] = 'R';
				}
			}
		}
	}
}

void SubGUIClass::onResetSelected( wxCommandEvent& event )
{
	//event that controls the reset button
	int answer = wxMessageBox("Reset game?", "Confirm", wxYES_NO, this);
	if (answer == wxYES)
	{
		m_button1->SetLabel("");
		m_button2->SetLabel("");
		m_button3->SetLabel("");
		m_button4->SetLabel("");
		m_button5->SetLabel("");
		m_button6->SetLabel("");
		m_button7->SetLabel("");
		m_button8->SetLabel("");
		m_button9->SetLabel("");

		for (int i = 0; i < 9; i++)
		{
			c[i] = 'R';
		}
	}
}

void SubGUIClass::displayStartUp( wxUpdateUIEvent& event )
{
	//controls the status bar with which turn it is
	if (isXturn)
	{
		SetStatusText("X's Turn", 0);
	}
	if (isOturn)
	{
		SetStatusText("O's Turn", 0);
	}
}
